# Charity Fund
A web application for fund collection of an organization.
##Setting Up
  * Copy all the file except Charity.sql to your server or localhost.
  * Create a database and import the Charity.sql file.
  * Change the connect.php file as your database modification.
  * Now go to http://yourIpAddress/CharityFund
  * Login with username: root & password: root

###Thank You!
